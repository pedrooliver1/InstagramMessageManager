# Instagram Message Manager — protótipo Android

Aplicativo de organização de mensagens com envio manual. Não conecta automaticamente à conta do Instagram e não automatiza disparos em massa.

## Gerar o APK na nuvem (sem computador com Android Studio)

1. Entre em https://github.com/ e crie uma conta, se necessário.
2. Crie um repositório novo.
3. Envie todos os arquivos desta pasta para o repositório, incluindo `.github/workflows/build-apk.yml`.
4. Abra a aba **Actions** e execute **Build Android APK** (ou envie os arquivos para a branch `main`/`master`).
5. Quando a execução terminar, abra-a e baixe o artefato `InstagramMessageManager-debug-apk`.
6. Extraia o artefato no celular e instale `app-debug.apk`. Se solicitado, permita a instalação pelo aplicativo usado para abrir o arquivo.

O workflow compila com Java e Gradle e publica o APK como artefato. Este ambiente de conversa não tem Android SDK/Gradle nem acesso à internet para baixar dependências, então não é possível compilar e validar o APK diretamente aqui.

## Limitações do protótipo atual

- Ainda não persiste as tarefas após encerrar o app.
- Agendamento e notificações persistentes precisam ser implementados e testados.
- O envio é manual: o app abre o Instagram, mas não lê listas de seguidores nem envia mensagens automaticamente.
