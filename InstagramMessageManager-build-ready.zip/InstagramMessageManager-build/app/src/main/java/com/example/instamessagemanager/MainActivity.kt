package com.example.instamessagemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val Ink = Color(0xFF100D18)
private val Panel = Color(0xFF211A30)
private val Purple = Color(0xFF9B72FF)
private val Muted = Color(0xFFBDB5CC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Ink, surface = Panel)) { Dashboard(onOpenInstagram = { openInstagram() }) } }
    }

    private fun openInstagram() {
        val launch = packageManager.getLaunchIntentForPackage("com.instagram.android")
        if (launch != null) startActivity(launch)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/")))
    }
}

data class CampaignTask(val handle: String, val message: String, val scheduled: String, val status: String)

@Composable
fun Dashboard(onOpenInstagram: () -> Unit) {
    var handle by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var scheduled by remember { mutableStateOf(LocalDateTime.now().plusHours(1).format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))) }
    var interval by remember { mutableStateOf("15") }
    var tasks by remember { mutableStateOf(listOf<CampaignTask>()) }
    var notice by remember { mutableStateOf("Campanhas ficam no aparelho. O envio é sempre manual.") }

    Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(48.dp).background(Purple, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text("M", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black) }
                    Column {
                        Text("MESSAGE MANAGER", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text("Planeje. Organize. Envie manualmente.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("${tasks.size}", "Tarefas", Modifier.weight(1f))
                    MetricCard("${tasks.count { it.status == "Pendente" }}", "Pendentes", Modifier.weight(1f))
                    MetricCard("Manual", "Modo", Modifier.weight(1f))
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Nova mensagem", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        OutlinedTextField(value = handle, onValueChange = { handle = it }, label = { Text("Usuário do Instagram") }, placeholder = { Text("@usuario") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("Texto da mensagem") }, placeholder = { Text("Escreva uma mensagem personalizada...") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = scheduled, onValueChange = { scheduled = it }, label = { Text("Data e hora (dd/MM/aaaa HH:mm)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = interval, onValueChange = { interval = it.filter(Char::isDigit).take(4) }, label = { Text("Intervalo entre tarefas (minutos)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (handle.isNotBlank() && message.isNotBlank() && runCatching { LocalDateTime.parse(scheduled, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")) }.isSuccess) {
                                tasks = tasks + CampaignTask(handle.trim().removePrefix("@"), message.trim(), scheduled.trim(), "Pendente")
                                handle = ""; message = ""; notice = "Tarefa adicionada à fila. Abra o Instagram para enviar manualmente."
                            } else notice = "Preencha usuário, mensagem e data/hora no formato indicado."
                        }, modifier = Modifier.fillMaxWidth()) { Text("Adicionar à fila") }
                        Text(notice, color = Muted, fontSize = 12.sp)
                    }
                }
            }
            item {
                Button(onClick = onOpenInstagram, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFCA3E86))) { Text("Abrir Instagram") }
            }
            item { Text("Fila de tarefas", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            if (tasks.isEmpty()) item { Text("Nenhuma tarefa cadastrada ainda.", color = Muted) }
            items(tasks) { task ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("@${task.handle}", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(task.status, color = Purple, fontSize = 12.sp)
                        }
                        Text(task.message, color = Muted, maxLines = 3)
                        Text("Agendado: ${task.scheduled}", color = Muted, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { tasks = tasks.map { if (it == task) it.copy(status = "Preparada") else it } }) { Text("Marcar preparada") }
                            OutlinedButton(onClick = { tasks = tasks.filterNot { it == task } }) { Text("Excluir") }
                        }
                    }
                }
            }
            item { Text("Privacidade: este protótipo não coleta seguidores, não acessa sua conta e não envia mensagens automaticamente.", color = Muted, fontSize = 11.sp) }
        }
    }
}

@Composable
private fun MetricCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier.widthIn(min = 80.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}
